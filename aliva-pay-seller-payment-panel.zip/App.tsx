import React from 'react';
import Dashboard from './components/Dashboard';

const AlivaPayLogo: React.FC = () => (
    <svg aria-label="Aliva Pay Logo" width="130" height="32" viewBox="0 0 130 32" xmlns="http://www.w3.org/2000/svg">
        <defs>
            <linearGradient id="logoGradient" x1="0%" y1="50%" x2="100%" y2="50%">
                <stop offset="0%" stop-color="#485EE4" />
                <stop offset="50%" stop-color="#4FA9EC" />
                <stop offset="100%" stop-color="#25c9d8" />
            </linearGradient>
        </defs>
        {/* A system font is used as a fallback for the custom brand font. The accent on 'a' is an approximation. */}
        <text 
            x="0" 
            y="25" 
            fontFamily="system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, 'Noto Sans', sans-serif" 
            fontSize="26" 
            fontWeight="bold" 
            fill="url(#logoGradient)"
        >
            Alivà Pay
        </text>
    </svg>
);


const App: React.FC = () => {
  return (
    <div className="flex flex-col min-h-screen bg-gray-50 text-gray-800">
      <header className="bg-aliva-primary shadow-md">
        <nav className="px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center">
              <AlivaPayLogo />
              <span className="text-gray-300 ml-2">| Panel de Vendedor</span>
            </div>
          </div>
        </nav>
      </header>
      <main className="flex-grow px-4 sm:px-6 lg:px-8 py-8 flex">
        <Dashboard />
      </main>
      <footer className="text-center py-4 text-gray-500 text-sm">
        <p>&copy; {new Date().getFullYear()} Aliva Pay Seller Panel. Todos los derechos reservados.</p>
      </footer>
    </div>
  );
};

export default App;