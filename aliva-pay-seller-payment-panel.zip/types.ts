import type React from 'react';

// Basado en la API del proveedor de pagos de Aliva Pay.
export interface FinancialInformation {
  cbu: string;
  alias: string;
  bank: string;
  holder_name: string;
  holder_cuit: string;
  account_type: 'savings' | 'checking';
}

export interface Entity {
  uid: string;
  name: string; // Business name
  cuit: string;
  email: string;
  phone: string;
  financial_information: FinancialInformation;
}

// FIX: Added PaymentMethod interface to define the shape of a payment method object.
export interface PaymentMethod {
  id: string;
  name: string;
  description: string;
  icon: React.FC<{ className?: string }>;
  fields: {
    id: string;
    label: string;
    type: 'text' | 'password' | 'email' | 'tel' | 'number';
    required: boolean;
    placeholder?: string;
  }[];
}

// FIX: Added SellerConfig interface to define the shape of a payment method's configuration.
export interface SellerConfig {
  enabled: boolean;
  data: { [key: string]: string };
}
