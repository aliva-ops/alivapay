
// FIX: Import SellerConfig type.
import type { Entity, SellerConfig } from '../types';

// --- MOCK DATABASE ---
// Simula un objeto Entidad de Aliva Pay para el vendedor logueado
let mockEntity: Entity = {
  uid: 'e4a2f8c1-1b23-4b56-8d90-12345abcdef',
  name: 'Mi Tienda Online S.R.L.',
  cuit: '30-12345678-9',
  email: 'ventas@mitienda.com',
  phone: '+541155558888',
  financial_information: {
    cbu: '0000003100000000000000',
    alias: 'mi.tienda.alivapay',
    bank: 'Banco Digital Aliva Pay',
    holder_name: 'Mi Tienda Online S.R.L.',
    holder_cuit: '30-12345678-9',
    account_type: 'checking',
  },
};

// FIX: Added mock database for seller payment method configurations.
let mockSellerConfigs: { [key: string]: SellerConfig } = {
  'credit_card': {
    enabled: true,
    data: {},
  },
  'mercado_pago': {
    enabled: false,
    data: {
      client_id: '',
      client_secret: ''
    }
  },
  'rapipago_pagofacil': {
    enabled: true,
    data: {}
  },
  'cmr_mastercard': {
    enabled: false,
    data: {
      api_key: '',
      merchant_id: ''
    }
  }
};


// --- MOCK API FUNCTIONS ---

/**
 * Simula la obtención de los detalles de la entidad del vendedor actual desde Aliva Pay.
 */
export const getEntityDetails = async (): Promise<Entity> => {
  console.log('API Call: Fetching entity details...');
  return new Promise(resolve => {
    setTimeout(() => {
      console.log('API Response: ', mockEntity);
      resolve(JSON.parse(JSON.stringify(mockEntity))); // Devuelve una copia profunda
    }, 800);
  });
};

/**
 * Simula la actualización de los detalles de la entidad del vendedor.
 * En un escenario real, esto sería una petición PUT a /entities/{uid}
 */
export const updateEntityDetails = async (entityData: Partial<Entity>): Promise<Entity> => {
  console.log(`API Call: Updating entity ${entityData.uid}...`, entityData);
  return new Promise(resolve => {
    setTimeout(() => {
      mockEntity = { ...mockEntity, ...entityData };
      console.log('API Response: New entity data saved', mockEntity);
      resolve(JSON.parse(JSON.stringify(mockEntity))); // Devuelve una copia profunda
    }, 1200);
  });
};

/**
 * Simula la obtención de las configuraciones de pago del vendedor.
 */
export const getSellerConfigs = async (): Promise<{ [key: string]: SellerConfig }> => {
  console.log('API Call: Fetching seller configs...');
  return new Promise(resolve => {
    setTimeout(() => {
      console.log('API Response: ', mockSellerConfigs);
      resolve(JSON.parse(JSON.stringify(mockSellerConfigs))); // Devuelve una copia profunda
    }, 600);
  });
};

// FIX: Added missing saveSellerConfig function to simulate saving payment method configurations.
/**
 * Simula el guardado de la configuración de un método de pago para un vendedor.
 */
export const saveSellerConfig = async (
  methodId: string,
  enabled: boolean,
  data: { [key: string]: string }
): Promise<SellerConfig> => {
  console.log(`API Call: Saving config for ${methodId}...`, { enabled, data });
  return new Promise(resolve => {
    setTimeout(() => {
      const newConfig = { enabled, data };
      mockSellerConfigs[methodId] = newConfig;
      console.log('API Response: New config saved', newConfig);
      resolve(JSON.parse(JSON.stringify(newConfig)));
    }, 1000);
  });
};