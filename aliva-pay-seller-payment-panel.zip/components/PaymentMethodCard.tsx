
import React from 'react';
import type { PaymentMethod } from '../types';

interface PaymentMethodCardProps {
  method: PaymentMethod;
  config?: { enabled: boolean };
  onConfigure: () => void;
}

const PaymentMethodCard: React.FC<PaymentMethodCardProps> = ({ method, config, onConfigure }) => {
  const isEnabled = config?.enabled === true;

  return (
    <div className="bg-white rounded-lg shadow-md hover:shadow-xl transition-shadow duration-300 flex flex-col">
      <div className="p-6 flex-grow">
        <div className="flex items-start justify-between">
          <div className="flex items-center space-x-4">
            <div className="bg-aliva-accent/10 p-3 rounded-full">
                <method.icon className="h-6 w-6 text-aliva-accent" />
            </div>
            <h3 className="text-lg font-semibold text-gray-800">{method.name}</h3>
          </div>
          <span className={`px-3 py-1 text-xs font-semibold rounded-full ${
            isEnabled ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'
          }`}>
            {isEnabled ? 'Activado' : 'Desactivado'}
          </span>
        </div>
        <p className="mt-4 text-gray-600 text-sm">
          {method.description}
        </p>
      </div>
      <div className="bg-gray-50 px-6 py-4 rounded-b-lg">
        <button
          onClick={onConfigure}
          className="w-full bg-aliva-accent text-white font-bold py-2 px-4 rounded-md hover:bg-aliva-accent/90 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-aliva-accent transition-colors duration-300"
        >
          {isEnabled ? 'Editar Configuración' : 'Configurar'}
        </button>
      </div>
    </div>
  );
};

export default PaymentMethodCard;
