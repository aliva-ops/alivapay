
import React, { useState, useEffect, useCallback, useReducer } from 'react';
import type { Entity } from '../types';
import { getEntityDetails, updateEntityDetails } from '../services/mobbexService';
import Spinner from './Spinner';
import Toast from './Toast';
import { UserIcon } from './icons/UserIcon';
import { CardIcon } from './icons/CardIcon';
import { ListIcon } from './icons/ListIcon';
import { BankIcon } from './icons/BankIcon';
import { HomeIcon } from './icons/HomeIcon';
import { LinkIcon } from './icons/LinkIcon';
import { LogoutIcon } from './icons/LogoutIcon';

type ActiveView = 'dashboard' | 'profile' | 'paymentMethods' | 'operations' | 'createPaymentLink';

// Reducer para una gestión más limpia del estado del formulario anidado
const formReducer = (state: Entity, action: { type: string, payload: any }): Entity => {
    switch (action.type) {
        case 'SET_ENTITY':
            return action.payload;
        case 'UPDATE_FIELD':
            return { ...state, [action.payload.field]: action.payload.value };
        case 'UPDATE_FINANCIAL_FIELD':
            return {
                ...state,
                financial_information: {
                    ...state.financial_information,
                    [action.payload.field]: action.payload.value
                }
            };
        default:
            return state;
    }
}

const NavButton: React.FC<{
  label: string;
  view: ActiveView;
  activeView: ActiveView;
  onClick: (view: ActiveView) => void;
  icon: React.ReactNode;
}> = ({ label, view, activeView, onClick, icon }) => {
  const isActive = activeView === view;
  return (
    <button
      onClick={() => onClick(view)}
      className={`flex items-center w-full text-left px-4 py-3 rounded-lg transition-colors duration-200 ${
        isActive
          ? 'bg-aliva-primary text-white shadow-md'
          : 'text-gray-600 hover:bg-gray-200 hover:text-gray-800'
      }`}
    >
      <div className="mr-3">{icon}</div>
      <span className="font-medium">{label}</span>
    </button>
  );
};


const Dashboard: React.FC = () => {
  const [initialEntity, setInitialEntity] = useState<Entity | null>(null);
  const [formData, dispatch] = useReducer(formReducer, {} as Entity);
  const [loading, setLoading] = useState<boolean>(true);
  const [isSaving, setIsSaving] = useState<boolean>(false);
  const [toast, setToast] = useState<{ message: string; type: 'success' | 'error' } | null>(null);
  const [activeView, setActiveView] = useState<ActiveView>('paymentMethods');

  const fetchData = useCallback(async () => {
    try {
      setLoading(true);
      const entity = await getEntityDetails();
      setInitialEntity(entity);
      dispatch({ type: 'SET_ENTITY', payload: entity });
    } catch (error) {
      console.error("Failed to fetch data:", error);
      setToast({ message: 'Error al cargar los datos de la entidad.', type: 'error' });
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    if (activeView === 'profile' && !initialEntity) {
        fetchData();
    } else {
        setLoading(false);
    }
  }, [activeView, fetchData, initialEntity]);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    const [section, field] = name.split('.');

    if (section === 'financial_information') {
        dispatch({ type: 'UPDATE_FINANCIAL_FIELD', payload: { field, value }});
    } else {
        dispatch({ type: 'UPDATE_FIELD', payload: { field: name, value }});
    }
  };
  
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSaving(true);
    try {
        const updatedEntity = await updateEntityDetails(formData);
        setInitialEntity(updatedEntity);
        dispatch({ type: 'SET_ENTITY', payload: updatedEntity });
        setToast({ message: 'Datos guardados con éxito.', type: 'success' });
    } catch (error) {
        console.error("Failed to save data:", error);
        setToast({ message: 'Error al guardar los datos.', type: 'error' });
    } finally {
        setIsSaving(false);
        setTimeout(() => setToast(null), 3000);
    }
  };

  const handleLogout = () => {
    // En una aplicación real, aquí también se limpiaría el estado de autenticación (tokens, etc.).
    window.location.href = 'https://alivapay1.odoo.com/';
  };
  
  const renderContent = () => {
    if (loading && activeView === 'profile') {
      return (
        <div className="flex justify-center items-center h-64">
          <Spinner />
        </div>
      );
    }
    
    if (!initialEntity && activeView === 'profile') {
        return <div className="text-center text-red-500">No se pudo cargar la información de la entidad.</div>
    }

    const iframeStyle = {
      width: 'calc(100% + 320px)',
      height: '1500px',
      marginLeft: '-320px',
    };

    switch (activeView) {
      case 'dashboard':
        return (
            <div className="bg-white p-6 sm:p-8 rounded-lg shadow-md space-y-4 flex flex-col h-full">
            <h2 className="text-xl font-semibold text-gray-800 border-b pb-3">
                Panel Principal
            </h2>
            <p className="text-md text-gray-600">
                Bienvenido a tu panel de control Aliva Pay. Utiliza la consola para una vista general de tu actividad.
            </p>
            <div className="w-full border rounded-lg overflow-hidden" style={{ height: '1500px' }}>
                <iframe
                    src="https://mobbex.com/console/6FB3HM4LW6TJ5ESY1YV424/"
                    className="border-0"
                    style={iframeStyle}
                    title="Consola Principal"
                    sandbox="allow-scripts allow-same-origin allow-forms allow-popups"
                ></iframe>
            </div>
            </div>
        );
      case 'profile':
        return (
          <div className="space-y-8">
            <div>
              <h1 className="text-3xl font-bold text-gray-900">Perfil y Datos de Liquidación</h1>
              <p className="mt-2 text-md text-gray-600">
                Mantén actualizada la información de tu negocio y la cuenta bancaria donde recibirás tus pagos.
              </p>
            </div>
            
            <form onSubmit={handleSubmit} className="bg-white p-6 sm:p-8 rounded-lg shadow-md space-y-8">
              {/* Entity Information */}
              <fieldset className="space-y-6">
                  <legend className="text-xl font-semibold text-gray-800 border-b pb-3 w-full">Información de la Entidad</legend>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div>
                          <label htmlFor="name" className="block text-sm font-medium text-gray-700">Razón Social</label>
                          <input type="text" name="name" id="name" value={formData.name || ''} onChange={handleInputChange} className="mt-1 block w-full input-style" required />
                      </div>
                       <div>
                          <label htmlFor="cuit" className="block text-sm font-medium text-gray-700">CUIT</label>
                          <input type="text" name="cuit" id="cuit" value={formData.cuit || ''} onChange={handleInputChange} className="mt-1 block w-full input-style" required />
                      </div>
                       <div>
                          <label htmlFor="email" className="block text-sm font-medium text-gray-700">Email de Contacto</label>
                          <input type="email" name="email" id="email" value={formData.email || ''} onChange={handleInputChange} className="mt-1 block w-full input-style" required />
                      </div>
                       <div>
                          <label htmlFor="phone" className="block text-sm font-medium text-gray-700">Teléfono</label>
                          <input type="tel" name="phone" id="phone" value={formData.phone || ''} onChange={handleInputChange} className="mt-1 block w-full input-style" />
                      </div>
                  </div>
              </fieldset>
      
              {/* Financial Information */}
              <fieldset className="space-y-6">
                   <legend className="flex items-center space-x-3 text-xl font-semibold text-gray-800 border-b pb-3 w-full">
                      <BankIcon className="h-6 w-6 text-aliva-accent"/>
                      <span>Información Financiera para Liquidaciones</span>
                   </legend>
                   <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div>
                          <label htmlFor="financial_information.holder_name" className="block text-sm font-medium text-gray-700">Nombre del Titular de la Cuenta</label>
                          <input type="text" name="financial_information.holder_name" id="financial_information.holder_name" value={formData.financial_information?.holder_name || ''} onChange={handleInputChange} className="mt-1 block w-full input-style" required />
                      </div>
                      <div>
                          <label htmlFor="financial_information.holder_cuit" className="block text-sm font-medium text-gray-700">CUIT del Titular</label>
                          <input type="text" name="financial_information.holder_cuit" id="financial_information.holder_cuit" value={formData.financial_information?.holder_cuit || ''} onChange={handleInputChange} className="mt-1 block w-full input-style" required />
                      </div>
                      <div>
                          <label htmlFor="financial_information.cbu" className="block text-sm font-medium text-gray-700">CBU</label>
                          <input type="text" name="financial_information.cbu" id="financial_information.cbu" value={formData.financial_information?.cbu || ''} onChange={handleInputChange} className="mt-1 block w-full input-style" required />
                      </div>
                      <div>
                          <label htmlFor="financial_information.alias" className="block text-sm font-medium text-gray-700">Alias (Opcional)</label>
                          <input type="text" name="financial_information.alias" id="financial_information.alias" value={formData.financial_information?.alias || ''} onChange={handleInputChange} className="mt-1 block w-full input-style" />
                      </div>
                   </div>
              </fieldset>
              
              <div className="pt-5 border-t">
                <div className="flex justify-end">
                  <button
                    type="submit"
                    disabled={isSaving}
                    className="w-full md:w-auto px-6 py-3 bg-aliva-accent text-white font-bold rounded-md shadow-sm hover:bg-aliva-accent/90 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-aliva-accent flex items-center justify-center disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    {isSaving ? <Spinner size="sm" /> : 'Guardar Cambios'}
                  </button>
                </div>
              </div>
            </form>
          </div>
        );
      case 'paymentMethods':
        return (
          <div className="bg-white p-6 sm:p-8 rounded-lg shadow-md space-y-4 flex flex-col h-full">
            <h2 className="text-xl font-semibold text-gray-800 border-b pb-3">
                Fuentes de Pago y Cuotas
            </h2>
            <p className="text-md text-gray-600">
                Administra tus métodos de pago, planes de cuotas y reglas de negocio directamente desde la consola de pagos.
            </p>
            <div className="w-full border rounded-lg overflow-hidden" style={{ height: '1500px' }}>
                <iframe
                    src="https://mobbex.com/console/6FB3HM4LW6TJ5ESY1YV424/sources/"
                    className="border-0"
                    style={iframeStyle}
                    title="Consola de Fuentes de Pago"
                    sandbox="allow-scripts allow-same-origin allow-forms allow-popups"
                ></iframe>
            </div>
          </div>
        );
      case 'operations':
        return (
          <div className="bg-white p-6 sm:p-8 rounded-lg shadow-md space-y-4 flex flex-col h-full">
            <h2 className="text-xl font-semibold text-gray-800 border-b pb-3">
                Operaciones y Transacciones
            </h2>
            <p className="text-md text-gray-600">
                Aquí puedes ver y gestionar todas tus operaciones, ventas y transacciones procesadas.
            </p>
            <div className="w-full border rounded-lg overflow-hidden" style={{ height: '1500px' }}>
                <iframe
                    src="https://mobbex.com/console/6FB3HM4LW6TJ5ESY1YV424/operations/"
                    className="border-0"
                    style={iframeStyle}
                    title="Consola de Operaciones"
                    sandbox="allow-scripts allow-same-origin allow-forms allow-popups"
                ></iframe>
            </div>
          </div>
        );
      case 'createPaymentLink':
        return (
          <div className="bg-white p-6 sm:p-8 rounded-lg shadow-md space-y-4 flex flex-col h-full">
            <h2 className="text-xl font-semibold text-gray-800 border-b pb-3">
                Crear Link de Pago
            </h2>
            <p className="text-md text-gray-600">
                Genera un link de pago para enviar a tus clientes de forma rápida y segura.
            </p>
            <div className="w-full border rounded-lg overflow-hidden" style={{ height: '1500px' }}>
                <iframe
                    src="https://mobbex.com/console/6FB3HM4LW6TJ5ESY1YV424/payment_order/"
                    className="border-0"
                    style={iframeStyle}
                    title="Consola para Crear Link de Pago"
                    sandbox="allow-scripts allow-same-origin allow-forms allow-popups"
                ></iframe>
            </div>
          </div>
        );
      default:
        return null;
    }
  }

  return (
    <>
      <div className="flex flex-col md:flex-row gap-8 w-full">
        <aside className="md:w-64 flex-shrink-0">
          <div className="bg-white p-4 rounded-lg shadow-md">
            <nav className="space-y-2">
               <NavButton 
                label="Dashboard"
                view="dashboard"
                activeView={activeView}
                onClick={setActiveView}
                icon={<HomeIcon className="h-5 w-5" />}
              />
              <NavButton 
                label="Perfil y Liquidación"
                view="profile"
                activeView={activeView}
                onClick={setActiveView}
                icon={<UserIcon className="h-5 w-5" />}
              />
               <NavButton 
                label="Fuentes de Pago"
                view="paymentMethods"
                activeView={activeView}
                onClick={setActiveView}
                icon={<CardIcon className="h-5 w-5" />}
              />
               <NavButton 
                label="Operaciones"
                view="operations"
                activeView={activeView}
                onClick={setActiveView}
                icon={<ListIcon className="h-5 w-5" />}
              />
              <NavButton 
                label="Crear Link de Pago"
                view="createPaymentLink"
                activeView={activeView}
                onClick={setActiveView}
                icon={<LinkIcon className="h-5 w-5" />}
              />
            </nav>
            <hr className="my-4" />
            <button
                onClick={handleLogout}
                className="flex items-center w-full text-left px-4 py-3 rounded-lg transition-colors duration-200 text-red-600 hover:bg-red-50 hover:text-red-700"
            >
                <div className="mr-3">
                    <LogoutIcon className="h-5 w-5" />
                </div>
                <span className="font-medium">Cerrar sesión</span>
            </button>
          </div>
        </aside>

        <main className="flex-1 min-w-0 flex flex-col overflow-y-auto">
          {renderContent()}
        </main>
      </div>

      {toast && (
          <Toast message={toast.message} type={toast.type} onClose={() => setToast(null)} />
      )}
      
      <style>{`
        .input-style {
            appearance: none;
            background-color: #fff;
            border-color: #d1d5db;
            border-width: 1px;
            border-radius: 0.375rem;
            padding: 0.5rem 0.75rem;
            font-size: 1rem;
            line-height: 1.5rem;
            box-shadow: 0 1px 2px 0 rgb(0 0 0 / 0.05);
        }
        .input-style:focus {
            outline: 2px solid transparent;
            outline-offset: 2px;
            box-shadow: 0 0 0 2px #25c9d8;
            border-color: #25c9d8;
        }
      `}</style>
    </>
  );
};

export default Dashboard;
