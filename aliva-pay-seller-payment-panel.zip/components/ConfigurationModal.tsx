
import React, { useState } from 'react';
import type { PaymentMethod, SellerConfig } from '../types';
import { saveSellerConfig } from '../services/mobbexService';
import Spinner from './Spinner';

interface ConfigurationModalProps {
  method: PaymentMethod;
  initialConfig?: { enabled: boolean; data: { [key: string]: string } };
  onClose: () => void;
  onSave: (newConfig: SellerConfig) => void;
  onSaveError: () => void;
}

const ConfigurationModal: React.FC<ConfigurationModalProps> = ({ method, initialConfig, onClose, onSave, onSaveError }) => {
  const [formData, setFormData] = useState<{ [key: string]: string }>(initialConfig?.data || {});
  const [isEnabled, setIsEnabled] = useState<boolean>(initialConfig?.enabled || false);
  const [isSaving, setIsSaving] = useState<boolean>(false);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { id, value } = e.target;
    setFormData(prev => ({ ...prev, [id]: value }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSaving(true);
    try {
      const newConfig = await saveSellerConfig(method.id, isEnabled, formData);
      onSave(newConfig);
      onClose();
    } catch (error) {
      console.error('Failed to save configuration:', error);
      onSaveError();
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex justify-center items-center p-4" onClick={onClose}>
      <div className="bg-white rounded-lg shadow-2xl w-full max-w-md transform transition-all" onClick={e => e.stopPropagation()}>
        <form onSubmit={handleSubmit}>
          <div className="p-6">
            <div className="flex items-center justify-between">
              <h2 className="text-2xl font-bold text-gray-900">Configurar {method.name}</h2>
              <button type="button" onClick={onClose} className="text-gray-400 hover:text-gray-600">
                <svg className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button>
            </div>
            
            <p className="mt-2 text-gray-600">{method.description}</p>
            
            <div className="mt-6 bg-gray-50 p-4 rounded-md flex items-center justify-between">
              <span className="font-medium text-gray-700">Activar método de pago</span>
              <label htmlFor="toggle" className="relative inline-flex items-center cursor-pointer">
                <input type="checkbox" id="toggle" className="sr-only peer" checked={isEnabled} onChange={() => setIsEnabled(!isEnabled)} />
                <div className="w-11 h-6 bg-gray-200 rounded-full peer peer-focus:ring-4 peer-focus:ring-blue-300 dark:peer-focus:ring-blue-800 dark:bg-gray-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-0.5 after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-gray-600 peer-checked:bg-aliva-accent"></div>
              </label>
            </div>

            {isEnabled && method.fields.length > 0 && (
              <div className="mt-6 space-y-4">
                {method.fields.map(field => (
                  <div key={field.id}>
                    <label htmlFor={field.id} className="block text-sm font-medium text-gray-700">
                      {field.label} {field.required && <span className="text-red-500">*</span>}
                    </label>
                    <input
                      type={field.type}
                      id={field.id}
                      value={formData[field.id] || ''}
                      onChange={handleInputChange}
                      placeholder={field.placeholder}
                      required={field.required}
                      className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-aliva-accent focus:border-aliva-accent sm:text-sm"
                    />
                  </div>
                ))}
              </div>
            )}
            
            {isEnabled && method.fields.length === 0 && (
                <div className="mt-6 p-4 bg-blue-50 text-blue-700 rounded-md text-sm">
                    No se requiere configuración adicional. Aliva Pay gestionará este método de pago por ti.
                </div>
            )}

          </div>
          <div className="bg-gray-50 px-6 py-4 flex justify-end space-x-3 rounded-b-lg">
            <button
              type="button"
              onClick={onClose}
              disabled={isSaving}
              className="px-4 py-2 bg-white text-gray-700 border border-gray-300 rounded-md shadow-sm hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gray-500 disabled:opacity-50"
            >
              Cancelar
            </button>
            <button
              type="submit"
              disabled={isSaving}
              className="px-4 py-2 bg-aliva-accent text-white font-bold rounded-md shadow-sm hover:bg-aliva-accent/90 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-aliva-accent flex items-center justify-center disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isSaving ? <Spinner size="sm" /> : 'Guardar Cambios'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default ConfigurationModal;
